import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import OSscreen from './screens/OSscreen';
import Homescreen from './screens/Homescreen';
import {createAppContainer,createSwitchNavigator} from 'react-navigation'


export default class App extends React.Component {
  render(){
  return (
    <View >
        <AppContainer/>
    
    </View>
  );
}
}

const styles = StyleSheet.create({
 /* container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },*/
});

const Appnavigator= createSwitchNavigator({
  Homescreen:{screen:Homescreen},
  OSscreen:{screen:OSscreen}
});

const AppContainer=createAppContainer(Appnavigator);
