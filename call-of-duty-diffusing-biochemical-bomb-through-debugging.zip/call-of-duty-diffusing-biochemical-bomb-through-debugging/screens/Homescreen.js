import * as React from 'react';
import { Text, View, StyleSheet,TouchableOpacity } from 'react-native';
import AppHeader from '../assets/AppHeader';




export default class Homescreen extends React.Component {
  render(){
  return (
    <View >
   <AppHeader/>
      <Text style={styles.xyz}>
        Debugging is the most important part of Programming since every
program will always have bugs.One sould stay calm and composed 
while debugging, it will help you to debug better. It is always a
good practice to print values or statements in console or comment
the section of your code to identify and fix the possible bugs.
There are a few bugs in this program....Let's see if you can 
identify and fix them to go to the next screen using "GO" button

All the best..!!


      </Text>
    <TouchableOpacity style={styles.gb} onPress={()=>{this.props.navigation.navigate('OSscreen')}}>
    <Text style={{marginLeft:'10px', fontSize:40,fontWeight:'bold',color:'purple'}}> GO</Text>
    </TouchableOpacity>
    </View>
  );
}
}
const styles = StyleSheet.create({
   xyz: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  gb:{
    justifyContent: 'center',
    alignSelf: 'center',
    borderWidth: 2,
    marginBottom:'',
    borderRadius: 100,
    marginTop: 50,
    width: 100,
    height: 100,
    backgroundColor:'red',
  }
});