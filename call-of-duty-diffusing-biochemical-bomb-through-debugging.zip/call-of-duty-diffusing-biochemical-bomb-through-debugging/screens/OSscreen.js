import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import AppHeader from '../assets/AppHeader';



export default class OSscreen extends React.Component {
  render(){
  return (
    <View>
    <AppHeader/>
      <Text style={styles.xyz}>
        Congartulation.....You debugged it..
      </Text>
    
    </View>
  );
}
}
const styles = StyleSheet.create({
   xyz: {
    margin: 24,
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});